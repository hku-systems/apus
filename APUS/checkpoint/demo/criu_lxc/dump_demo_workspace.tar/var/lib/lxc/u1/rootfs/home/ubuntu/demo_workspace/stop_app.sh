#!/bin/sh

pkill -f count.sh
