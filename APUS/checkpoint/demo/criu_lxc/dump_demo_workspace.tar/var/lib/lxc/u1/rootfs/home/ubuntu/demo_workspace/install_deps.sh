#!/bin/sh

sudo cp ./deps/lib* /lib/x86_64-linux-gnu/
sudo cp ./deps/criu /sbin/
